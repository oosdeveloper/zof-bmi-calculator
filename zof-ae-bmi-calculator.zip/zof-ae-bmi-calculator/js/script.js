        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('bmi-calculator-form');
            const overlay = document.getElementById('overlay');
            const resultPopup = document.getElementById('result-popup');
            const bmiResult = document.getElementById('bmi-result');
            const bmiCategory = document.getElementById('bmi-category');
            const closePopup = document.getElementById('close-popup');

            form.addEventListener('submit', function(event) {
                event.preventDefault();

                // Retrieve user inputs
                const height = parseFloat(document.getElementById('height').value) / 100; // Convert to meters
                const weight = parseFloat(document.getElementById('weight').value);

                // Display "Calculating..." message
                bmiResult.innerHTML = "Calculating...";
                bmiCategory.innerHTML = "";
                resultPopup.style.display = 'block';
                //overlay.style.display = 'block';

                // Calculate BMI (Body Mass Index)
                const bmi = calculate_bmi(height, weight);

                // Determine BMI category
                const category = determine_bmi_category(bmi);

                // Display the result in the pop-up
                bmiResult.innerHTML = `Your BMI is: <span class="${category}-color">${bmi.toFixed(2)}</span>`;
                bmiCategory.innerHTML = `Category: <span class="${category}-color">${category}</span>`;
            });

            // Close the pop-up when the "Close" button is clicked
            closePopup.addEventListener('click', function() {
                resultPopup.style.display = 'none';
                overlay.style.display = 'none';
            });

            // Function to calculate BMI
            function calculate_bmi(height, weight) {
                return weight / (height * height);
            }

            // Function to determine BMI category
            function determine_bmi_category(bmi) {
                if (bmi < 18.5) {
                    return 'Underweight';
                } else if (bmi >= 18.5 && bmi < 24.9) {
                    return 'Normal Weight';
                } else if (bmi >= 25 && bmi < 29.9) {
                    return 'Overweight';
                } else {
                    return 'Obese';
                }
            }
        });