<?php
/*
Plugin Name: BMI Calculator
Description: A simple BMI calculator tool with a pop-up result.
Version: 1.0
Author: <a href="https://zof.ae" target="_blank">zof.ae</a>
*/

function add_author_link_to_plugin_bmi_meta($plugin_meta, $plugin_file, $plugin_data, $status) {
    if (strpos($plugin_file, 'bmi-calculator.php') !== false) {
        $author_url = 'https://zof.ae'; 
        $author_link = '<a href="' . esc_url($author_url) . '" target="_blank">ZOF TECHNOLOGY</a>';
        $plugin_meta['author_link'] = $author_link;
    }
    return $plugin_meta;
}
add_filter('plugin_row_meta', 'add_author_link_to_plugin_bmi_meta', 10, 4);

// Add the BMI calculator form with unit selection
function bmi_calculator_form() {
    ob_start(); ?>
    <style>
        /* Add CSS styles for the form container */
        .bmi-calculator-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
            border-radius: 5px;
        }

        /* Add CSS styles for form labels */
        label {
            font-weight: bold;
        }

        /* Add CSS styles for input fields */
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        /* Add CSS styles for the submit button */
        input[type="submit"] {
            background-color: #0073e6;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        /* Add CSS styles for the overlay */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 9998;
        }

        /* Add CSS styles for the result pop-up */
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            border-radius: 5px;
            z-index: 9999;
        }

        /* Add CSS styles for the result pop-up content */
        .popup-content {
            text-align: center;
        }

        /* Add CSS styles for the close button */
        .close-button {
            background-color: #0073e6;
            color: white;
            border: none;
            border-radius: 3px;
            padding: 5px 10px;
            cursor: pointer;
        }

        /* Add CSS styles for BMI categories */
        .bmi-category {
            font-weight: bold;
        }

        /* Add CSS styles for the powered-by label */
        .powered-by-label {
            margin-top: 10px;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('bmi-calculator-form');
            const overlay = document.getElementById('overlay');
            const resultPopup = document.getElementById('result-popup');
            const bmiResult = document.getElementById('bmi-result');
            const bmiCategory = document.getElementById('bmi-category');
            const closePopup = document.getElementById('close-popup');

            form.addEventListener('submit', function(event) {
                event.preventDefault();

                // Retrieve user inputs
                const height = parseFloat(document.getElementById('height').value);
                const weight = parseFloat(document.getElementById('weight').value);
                const unit = document.querySelector('input[name="unit"]:checked').value;

                // Display "Calculating..." message
                bmiResult.innerHTML = "Calculating...";
                bmiCategory.innerHTML = "";
                resultPopup.style.display = 'block';

                // Calculate BMI (Body Mass Index) based on the selected unit
                const bmi = unit === 'kg_cm' ? calculate_bmi_kg_cm(height, weight) : calculate_bmi_lb_ft(height, weight);

                // Determine BMI category
                const category = determine_bmi_category(bmi);

                // Display the result in the pop-up
                bmiResult.innerHTML = `Your BMI is: <span class="${category}-color">${bmi.toFixed(2)}</span>`;
                bmiCategory.innerHTML = `Category: <span class="${category}-color">${category}</span>`;
            });

            // Close the pop-up when the "Close" button is clicked
            closePopup.addEventListener('click', function() {
                resultPopup.style.display = 'none';
                overlay.style.display = 'none';
            });

            // Function to calculate BMI in KG/CM
            function calculate_bmi_kg_cm(height, weight) {
                const heightInMeters = height / 100;
                return weight / (heightInMeters * heightInMeters);
            }

            // Function to calculate BMI in LB/FT
            function calculate_bmi_lb_ft(height, weight) {
                const heightInMeters = height * 0.3048;
                return (weight * 0.45359237) / (heightInMeters * heightInMeters);
            }

            // Function to determine BMI category
            function determine_bmi_category(bmi) {
                if (bmi < 18.5) {
                    return 'Underweight';
                } else if (bmi >= 18.5 && bmi < 24.9) {
                    return 'Normal Weight';
                } else if (bmi >= 25 && bmi < 29.9) {
                    return 'Overweight';
                } else {
                    return 'Obese';
                }
            }
        });
    </script>
    <div class="bmi-calculator-container">
        <!-- Add a title here -->
        <h2>BMI Calculator</h2>
        <form id="bmi-calculator-form">
            <label for="unit_kg_cm">
                <input type="radio" name="unit" id="unit_kg_cm" value="kg_cm" checked> KG/CM
            </label>
            <label for="unit_lb_ft">
                <input type="radio" name="unit" id="unit_lb_ft" value="lb_ft"> LB/FT
            </label>
            <br>
            <!-- Height (in centimeters) or (in feet) -->
            <label for="height">Height:</label>
            <input type="number" name="height" id="height" step="0.01" required>

            <!-- Weight (in kilograms) or (in pounds) -->
            <label for="weight">Weight:</label>
            <input type="number" name="weight" id="weight" step="0.01" required>
            <input type="submit" value="Calculate">
        </form>

        <!-- Powered by ZOF.AE label with a hyperlink -->
        <div class="powered-by-label">
            Powered by <a href="https://zof.ae" target="_blank">ZOF.AE</a>
        </div>
    </div>

    <!-- Result Pop-up -->
    <div class="overlay" id="overlay"></div>
    <div class="popup" id="result-popup">
        <div class="popup-content">
            <h2>BMI Calculator</h2>
            <p id="bmi-result"></p>
            <p id="bmi-category"></p>
            <button class="close-button" id="close-popup">Close</button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// Create a shortcode to display the BMI calculator
add_shortcode('bmi_calculator', 'bmi_calculator_form');