=== BMI Calculator Plugin ===

Contributors: ZOF TECHNOLOGY
Tags: bmi calculator, health, fitness, body mass index
Tested up to: 6.3.1
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The BMI Calculator Plugin is a simple and effective tool for calculating your Body Mass Index (BMI). It helps you assess your BMI based on your height and weight, providing insights into whether you are underweight, have a normal weight, are overweight, or obese.

== Features ==

- Calculate your BMI based on your height and weight.
- Customizable units for weight (e.g., KG/CM or LB/FT).
- Provides a pop-up result with your calculated BMI and an interpretation of your BMI category.
- Easy-to-use form integrated into your WordPress site.
- Supports both metric and imperial measurements.

== Installation ==

1. Upload the "bmi-calculator" folder to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Use the `[bmi_calculator]` shortcode to add the calculator to your pages or posts.

== Usage ==

1. Create or edit a page or post where you want to display the BMI calculator.
2. Add the `[bmi_calculator]` shortcode to the content.
3. Save or update the page/post.
4. Visitors to your site can now use the BMI calculator to calculate their BMI and understand their weight category.

== Frequently Asked Questions ==

= Can I customize the units for weight and height? =

Yes, you can customize the units for weight (KG/CM or LB/FT) using the form provided by the plugin.

= How do I change the units for weight and height? =

Visitors can choose their preferred units (KG/CM or LB/FT) when using the BMI calculator. The form is user-friendly and allows for unit selection.

= Is this plugin free to use? =

Yes, the BMI Calculator Plugin is free to use and is released under the GPL-2.0 license.

== Changelog ==

= 1.0 =
* Initial release of the BMI Calculator Plugin.

== Upgrade Notice ==

= 1.0 =
Initial release.

== License ==

This plugin is licensed under the GNU General Public License v2 or later:

- License: GPLv2 or later
- License URI: https://www.gnu.org/licenses/gpl-2.0.html
